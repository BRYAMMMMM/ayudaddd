package ec.edu.ups.ppw.biblioteca.model;

import ec.edu.ups.ppw.biblioteca.Libros;
import ec.edu.ups.ppw.biblioteca.dao.LibroDAO;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.Singleton;
import jakarta.ejb.Startup;
import jakarta.inject.Inject;
@Startup
@Singleton
public class Inicio {
	 @Inject
	    private LibroDAO daoLibro;
	    @PostConstruct
	    public void init() {
	    	Libros libro = new Libros();
	    	libro.setAutor("Gabriel García Márquez");
	        libro.setDescripcion("Cien años de soledad es una novela que cuenta la historia de la familia Buendía a lo largo de varias generaciones en el ficticio pueblo de Macondo.");
	        libro.setEditorial("Editorial Sudamericana");
	        libro.setGenero("Realismo mágico");
	        libro.setTitulo("Cien años de soledad");
	        libro.setPortada("https://th.bing.com/th/id/OIP.i1l4x9xyOWqAe0fHkss9NwHaLQ?w=202&h=308&c=7&r=0&o=5&dpr=1.3&pid=1.7");


			daoLibro.insert(libro);
	    }
}
